Mini Project: Blog System (Laravel + React)
Objective: Develop a simple blog system where users can create, read, update, and delete
blog posts. Users can also comment on posts. Authentication should be handled using Laravel
Sanctum.
1. Functional Requirements
1.1 User Authentication
• Users can register and log in using email and password.
• Authentication should be handled using Laravel Sanctum.
• Authenticated users can log out.
• Users should be able to update their profile (name, email).
1.2 Blog Posts Management
• Users can create a new blog post.
• Users can edit their own blog posts.
• Users can delete their own blog posts.
• Posts should include:
o Title (max 255 characters, required)
o Content (text, required)
o Image (optional)
o Published At (timestamp, optional)
1.3 Comments System
• Authenticated users can comment on a post.
• Comments should include:
o User who posted the comment
o Content (max 500 characters, required)
o Timestamp of creation
• Comments should be listed under each post.
• Users can delete their own comments.
1.4 Public and Private Content
• All users (even guests) can view blog posts and comments.
• Only authenticated users can create/edit/delete posts and comments.
1.5 Search & Filtering
• Users should be able to search for blog posts by title.
• Users should be able to filter posts by author.
2. Technical Requirements
2.1 Backend (Laravel)
• Laravel 10+ should be used for API development.
• Use Laravel Sanctum for authentication.
• Use Eloquent ORM to define relationships:
o User → hasMany → Post
o Post → hasMany → Comment
o Comment → belongsTo → User
• Use form request validation for data validation.
• Implement API pagination for the list of blog posts.
• Use Laravel storage for handling image uploads.
• Handle error messages properly with response codes.
2.2 API Endpoints
Authentication
• POST /api/register → Register a new user
• POST /api/login → Login
• POST /api/logout → Logout (Authenticated users only)
Blog Posts
• GET /api/posts → List all posts (paginated)
• GET /api/posts/{id} → Get a single post with comments
• POST /api/posts → Create a new post (Authenticated users only)
• PUT /api/posts/{id} → Edit a post (Only the owner can edit)
• DELETE /api/posts/{id} → Delete a post (Only the owner can delete)
Comments
• POST /api/posts/{id}/comments → Add a comment to a post (Authenticated users
only)
• DELETE /api/comments/{id} → Delete a comment (Only the owner can delete)
2.3 Frontend (React)
• Use React (Vite) with React Router for navigation.
• Use Axios for API calls.
• Use React Query or useEffect with useState for fetching data.
• Login Page: Form with email/password authentication.
• Dashboard Page:
o Show a list of blog posts (title, author, and short preview).
o Pagination for large lists.
o Search bar to filter posts by title.
• Post Details Page:
o Show full content of the post.
o Display comments under the post.
o Allow authenticated users to post comments.
• New/Edit Post Page:
o Form to create/edit a post.
o Only the owner of a post can edit or delete it.
3. Bonus Features (Optional)
• Implement soft deletes for posts and comments.
• Add real-time comments using WebSockets or Laravel Echo.
• Implement role-based access control (Admin vs. Regular User).
• Add a like system for posts and comments.
4. Project Submission Guidelines
• Provide a GitHub repository with backend (/backend) and frontend (/frontend)
directories.
• Include clear installation steps in a README.md file.
• Ensure API responses are properly structured (status, message, data).
• Use .env.example for environment variables.
• The Laravel backend should have proper migrations and seeders for initial data.
• Follow best practices for code structure and readability.
• Submission should be done within 24hours.

I'll help you implement this Blog System with Laravel and React. Let's break this down into a structured approach to build the entire application within the required timeframe.

Project Structure Overview
We'll create a full-stack application with Laravel backend API and React frontend. Here's how we'll approach this:

Set up the backend Laravel application with proper models, controllers, and API endpoints
Implement authentication using Laravel Sanctum
Develop the React frontend with all required pages and features
Connect everything together
Let's start with the implementation:

Backend (Laravel) Implementation

Laravel Backend Setup
Code 
Now, let's define our database migrations for the Posts and Comments tables:


Laravel Migrations
Code 
Next, let's create our Eloquent models with the relationships:


Laravel Models
Code 
Let's implement our Form Requests for validation:


Laravel Form Requests
Code 
Now let's implement the Controllers to handle our API functionality:


Laravel Controllers
Code 
Now, let's set up our API routes:


Laravel API Routes
Code 
Let's create a database seeder to populate our database with some initial data:


Laravel Database Seeder
Code 
Now let's configure CORS for our API to allow frontend access:


Laravel CORS Configuration
Code 
Frontend (React) Implementation
Let's set up the React frontend using Vite:


React Frontend Setup
Code 
Now, let's implement the API service:


React API Service
Code 
Let's implement the authentication context:


React Auth Context
Code 
Now, let's create a protected route component:


React Protected Route
Code 
Let's create the main components of our application:


React Components
Code 






// config/cors.php
<?php

return [
    'paths' => ['api/*', 'sanctum/csrf-cookie'],
    'allowed_methods' => ['*'],
    'allowed_origins' => ['http://localhost:5173'], // Vite default dev server
    'allowed_origins_patterns' => [],
    'allowed_headers' => ['*'],
    'exposed_headers' => [],
    'max_age' => 0,
    'supports_credentials' => true,
];